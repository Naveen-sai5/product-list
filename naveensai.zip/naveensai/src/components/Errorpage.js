import React from 'react'

const Errorpage = () => {
  return (
    <div>Errorpage</div>
  )
}

export default Errorpage