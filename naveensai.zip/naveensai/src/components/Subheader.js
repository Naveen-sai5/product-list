import React from 'react'

const Subheader = () => {
  return (
    <>
        <hr/>
            <p>hi</p>
        <hr/>
    </>
  )
}

export default Subheader